using UnityEngine;

public class CameraManager : MonoBehaviour
{
    public static CameraManager Instance;

    CameraFollow follow;

    private void Awake()
    {
        Instance = this;
        follow = GetComponent<CameraFollow>();
        if (GetComponent<RearThreatCamera>() == null) gameObject.AddComponent<RearThreatCamera>();
    }

    public void SetTarget(GameObject target)
    {
        follow.SetTarget(target);
    }

    public void SetCam(bool temp)
    {
        follow.setAim(temp);
    }
    public void SetLockTarget(Player target)
    {
        follow?.SetLockTarget(target);
    }

}
