using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

[DisallowMultipleComponent]
public sealed class PlayerTitleLabel : MonoBehaviour
{
    public static bool IsTitleObject(string name) =>
        string.Equals(name?.Trim(), "chingho", System.StringComparison.OrdinalIgnoreCase) ||
        string.Equals(name?.Trim(), "chinho", System.StringComparison.OrdinalIgnoreCase);
    [Tooltip("프로필 카드 등 다른 플레이어의 칭호라면 해당 PlayerData를 지정합니다.")]
    [SerializeField] private PlayerData player;
    [SerializeField] private bool useLocalAccount = true;
    private TMP_Text label;
    private int shown;
    private bool hasShownTitle;
    private void Awake() {label=GetComponent<TMP_Text>();}
    private void OnEnable()
    {
        DataConfig.Changed += Refresh;
        DataConfig.SnapshotApplied += Refresh;
        DatabaseManager.DataConfigReadyChanged += Refresh;
        if (player != null) player.EquippedTitleChanged += Refresh;
        hasShownTitle = false;
        Refresh();
    }
    private void OnDisable()
    {
        DataConfig.Changed -= Refresh;
        DataConfig.SnapshotApplied -= Refresh;
        DatabaseManager.DataConfigReadyChanged -= Refresh;
        if (player != null) player.EquippedTitleChanged -= Refresh;
    }
    private void Refresh()
    {
        int id=useLocalAccount?(TitleProgression.Ready?DataConfig.equippedTitleId:0):
            player!=null && player.Object!=null && player.Object.IsValid?player.EquippedTitleId:0;
        // Negative IDs are valid bot titles, so no title ID can serve as an uninitialized marker.
        if(label==null || (hasShownTitle && shown==id))return;
        shown=id;hasShownTitle=true;label.richText=false;label.text=TitleCatalog.Name(id);
    }
    public void SetPlayer(PlayerData data)
    {
        if (isActiveAndEnabled && player != null) player.EquippedTitleChanged -= Refresh;
        player=data;useLocalAccount=false;hasShownTitle=false;
        if (isActiveAndEnabled && player != null) player.EquippedTitleChanged += Refresh;
        Refresh();
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Bootstrap()
    {
        SceneManager.sceneLoaded-=SceneLoaded;
        SceneManager.sceneLoaded+=SceneLoaded;
        InstallLabels();
    }
    private static void SceneLoaded(Scene scene,LoadSceneMode mode)=>InstallLabels();
    private static void InstallLabels()
    {
        foreach(var text in FindObjectsByType<TMP_Text>(FindObjectsInactive.Include,FindObjectsSortMode.None)) {
            if(!text.gameObject.scene.isLoaded || !IsTitleObject(text.name))continue;
            bool award=false,remote=false;
            for(Transform p=text.transform.parent;p!=null;p=p.parent) {
                if(p.name=="MVPUI")award=true;
                if(p.name=="TabUI" || p.name=="VSUI" || p.name.Contains("WaitingRoom"))remote=true;
            }
            if(award)continue; // MVP award category is not an equipped account title.
            var label=text.GetComponent<PlayerTitleLabel>() ?? text.gameObject.AddComponent<PlayerTitleLabel>();
            if(remote)label.SetPlayer(null);
        }
    }
    // Called by the profile UI at its existing roster refresh, not by a global frame search.
    public static void Bind(Transform root,PlayerData data)
    {
        if(root==null)return;
        var group=root.GetComponent<PlayerTitleLabelGroup>() ?? root.gameObject.AddComponent<PlayerTitleLabelGroup>();
        group.Bind(data);
    }
}

public sealed class PlayerTitleLabelGroup : MonoBehaviour
{
    private PlayerTitleLabel[] labels;
    private PlayerData current;
    public void Bind(PlayerData data)
    {
        if(labels==null) {
            var list=new System.Collections.Generic.List<PlayerTitleLabel>();
            foreach(var text in GetComponentsInChildren<TMP_Text>(true))
                if(PlayerTitleLabel.IsTitleObject(text.name))
                    list.Add(text.GetComponent<PlayerTitleLabel>() ?? text.gameObject.AddComponent<PlayerTitleLabel>());
            labels=list.ToArray();
        }
        if(current==data && data!=null)return;
        current=data;foreach(var label in labels)if(label!=null)label.SetPlayer(data);
    }
}
