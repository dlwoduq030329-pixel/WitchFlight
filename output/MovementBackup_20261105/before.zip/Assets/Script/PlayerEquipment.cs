using UnityEngine;

public class PlayerEquipment : MonoBehaviour
{
    [Header("Pre-placed scene objects (MagicType enum index order)")]
    [SerializeField] private GameObject[] magicStaffPrefabs;

    [Header("Pre-placed scene objects (HatType enum index order)")]
    [SerializeField] private GameObject[] hatPrefabs;

    [Header("Pre-placed scene objects (BroomType enum index order)")]
    [SerializeField] private GameObject[] broomPrefabs;

    private GameObject magicStaff1;
    private GameObject magicStaff2;
    private MagicType magic1;
    private MagicType magic2;
    private int currentMagicSlot;
    private int currentHatIndex;
    private int currentBroomIndex;
    private bool flightEquipmentVisible = true;
    private bool weaponVisible = true;
    private bool followsDataConfig;
    private bool hasLocalLoadout;
    public GameObject CurrentBroomObject => broomPrefabs != null && currentBroomIndex > 0 &&
        currentBroomIndex < broomPrefabs.Length ? broomPrefabs[currentBroomIndex] : null;

    public bool IsFlightEquipment(Transform part)
    {
        if (part == null) return false;
        if (magicStaffPrefabs != null) foreach (var item in magicStaffPrefabs)
            if (item != null && part.IsChildOf(item.transform)) return true;
        if (broomPrefabs != null) foreach (var item in broomPrefabs)
            if (item != null && part.IsChildOf(item.transform)) return true;
        return false;
    }

    private void OnEnable()
    {
        if (!followsDataConfig) return;
        DataConfig.Changed += ApplyFromDataConfig;
        ApplyFromDataConfig();
    }

    private void OnDisable() => DataConfig.Changed -= ApplyFromDataConfig;

    // Like PlayerAppearance, only the Main preview explicitly observes local settings.
    // No UI needs a reference to this component to equip a spell: edit DataConfig instead.
    public void BindToDataConfig()
    {
        followsDataConfig = true;
        hasLocalLoadout = false;
        DataConfig.Changed -= ApplyFromDataConfig;
        if (isActiveAndEnabled) DataConfig.Changed += ApplyFromDataConfig;
        ApplyFromDataConfig();
    }

    public void UnbindFromDataConfig()
    {
        followsDataConfig = false;
        hasLocalLoadout = false;
        DataConfig.Changed -= ApplyFromDataConfig;
    }

    private void ApplyFromDataConfig()
    {
        if (!followsDataConfig) return;
        int first = DataConfig.magic1Index, second = DataConfig.magic2Index;
        bool firstChanged = (int)magic1 != first;
        bool secondChanged = (int)magic2 != second;
        if (!hasLocalLoadout || firstChanged || secondChanged)
        {
            // Show the staff just equipped. Unrelated hair/color edits do not reset it.
            int slot = hasLocalLoadout && !firstChanged && secondChanged ? 2 : 1;
            ApplyMagicSelection(first, second, slot);
        }
        if (!hasLocalLoadout || currentHatIndex != DataConfig.hatIndex) EquipHat(DataConfig.hatIndex);
        if (!hasLocalLoadout || currentBroomIndex != DataConfig.broomIndex) EquipBroom(DataConfig.broomIndex);
        hasLocalLoadout = true;
    }

    // Presentation only: keep selections so leaving the lobby does not erase a loadout.
    public void SetFlightEquipmentVisible(bool visible)
    {
        if (flightEquipmentVisible == visible) return;
        flightEquipmentVisible = visible;
        int slot = currentMagicSlot;
        currentMagicSlot = 0;
        ChangeMagic(slot);
        SetOnlyActive(broomPrefabs, visible ? currentBroomIndex : 0);
        if (!visible) SetAllInactive(magicStaffPrefabs);
    }

    // Two-handed flying hides only the staff. Keep the chosen spell and broom intact.
    public void SetWeaponVisible(bool visible)
    {
        if (weaponVisible == visible) return;
        weaponVisible = visible;
        int slot = currentMagicSlot;
        currentMagicSlot = 0;
        ChangeMagic(slot);
    }

    public void Init(MagicType magic1, MagicType magic2, HatType hat, BroomType broom)
    {
        ApplyLoadout(hat, broom, magic1, magic2);
    }

    // All objects are authored as children of ChPrefab. This method only
    // switches their active state; it never instantiates or destroys equipment.
    public void ApplyLoadout(HatType selectedHat, BroomType selectedBroom,
        MagicType selectedMagic1, MagicType selectedMagic2)
    {
        // Battle calls this with the replicated PlayerData/Player snapshot.
        // Never let local account settings change a remote character's weapon.
        UnbindFromDataConfig();
        magic1 = selectedMagic1;
        magic2 = selectedMagic2;

        SetAllInactive(magicStaffPrefabs);
        magicStaff1 = FindMagicObject(magic1);
        magicStaff2 = FindMagicObject(magic2);
        currentMagicSlot = 0;
        ChangeMagic(1);

        EquipHat((int)selectedHat);
        EquipBroom((int)selectedBroom);
    }

    public void ChangeMagic(int slot)
    {
        // 3번은 기획서의 고정 패링 슬롯입니다. 지팡이를 생성하지 않고
        // 이미 배치된 두 일반 마법 지팡이만 활성/비활성 전환합니다.
        if (slot < 1 || slot > 3)
            return;

        if (currentMagicSlot == slot)
            return;

        if (magicStaff1 != null)
            magicStaff1.SetActive(false);
        if (magicStaff2 != null)
            magicStaff2.SetActive(false);

        GameObject selectedStaff = slot == 1
            ? magicStaff1
            : slot == 2
                ? magicStaff2
                : null;
        if (selectedStaff != null)
            selectedStaff.SetActive(flightEquipmentVisible && weaponVisible);

        currentMagicSlot = slot;
    }

    public void EquipMagic(int selectedMagic1, int selectedMagic2)
    {
        ApplyMagicSelection(selectedMagic1, selectedMagic2, 1);
    }

    private void ApplyMagicSelection(int selectedMagic1, int selectedMagic2, int visibleSlot)
    {
        magic1 = (MagicType)selectedMagic1;
        magic2 = (MagicType)selectedMagic2;
        SetAllInactive(magicStaffPrefabs);
        magicStaff1 = FindMagicObject(magic1);
        magicStaff2 = FindMagicObject(magic2);
        currentMagicSlot = 0;
        ChangeMagic(visibleSlot);
    }

    public void EquipHat(int index)
    {
        currentHatIndex = index;
        SetOnlyActive(hatPrefabs, index);
    }

    public void EquipBroom(int index)
    {
        currentBroomIndex = index;
        SetOnlyActive(broomPrefabs, flightEquipmentVisible ? index : 0);
    }

    private GameObject FindMagicObject(MagicType magic)
    {
        int index = (int)magic;
        if (magicStaffPrefabs == null || index <= 0 || index >= magicStaffPrefabs.Length)
            return null;

        return magicStaffPrefabs[index];
    }

    private void SetOnlyActive(GameObject[] objects, int activeIndex)
    {
        if (objects == null)
            return;

        for (int index = 0; index < objects.Length; index++)
        {
            if (objects[index] != null)
                objects[index].SetActive(index == activeIndex && index > 0);
        }
    }

    private void SetAllInactive(GameObject[] objects)
    {
        if (objects == null)
            return;

        foreach (GameObject equipmentObject in objects)
        {
            if (equipmentObject != null)
                equipmentObject.SetActive(false);
        }
    }
}

